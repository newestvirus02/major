
const MoMo = require('../src/index');

async function run(){
  const momo = new MoMo({ provider: 'auto', env: 'sandbox', webhookSecret: 'test' });
  
  console.log('📱 Testing Zambia validation...');
  console.log('Valid +260976000000:', require('../src/utils').validatePhone('+260976000000'));
  console.log('Detect 097 ->', require('../src/utils').detectProvider('+260976000000'));
  console.log('Detect 076 ->', require('../src/utils').detectProvider('+260760000000'));

  console.log('\n💸 Collect test...');
  const res = await momo.collect({ phone: '+260976000000', amount: 150, reference: 'TEST-'+Date.now() });
  console.log(res);

  console.log('\n⏳ Polling status...');
  await new Promise(r=>setTimeout(r,3500));
  const status = await momo.checkStatus(res.transactionId);
  console.log(status);

  console.log('\n🧾 Receipt...');
  const receipt = await momo.generateReceipt({ transactionId: res.transactionId, provider: 'mtn', amount: 150, fee: 3, phone: '+260976000000', reference: res.reference });
  require('fs').writeFileSync('receipt-test.pdf', receipt);
  console.log('Saved receipt-test.pdf', receipt.length, 'bytes');

  console.log('\n🔐 Webhook signature test...');
  const sig = momo.createSignature({ transactionId: res.transactionId, status: 'SUCCESSFUL' });
  console.log('Signature:', sig);
}

run();
