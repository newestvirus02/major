
const express = require('express');
const MoMo = require('../src/index');

const app = express();
app.use(express.json({ verify: (req,res,buf) => { req.rawBody = buf.toString(); } }));

const momo = new MoMo({
  provider: 'auto',
  env: 'sandbox',
  webhookSecret: 'test_secret_zm_2024',
  mtn: { subscriptionKey: '', apiKey: '', apiUser: '', callbackUrl: 'http://localhost:3000/webhook/momo' },
  airtel: { clientId: '', clientSecret: '', callbackUrl: 'http://localhost:3000/webhook/momo' }
});

app.post('/api/collect', async (req,res)=>{
  try {
    const result = await momo.collect(req.body);
    res.json(result);
  } catch(e){ res.status(400).json({ error: e.message }); }
});

app.post('/api/status/:id', async (req,res)=>{
  try {
    const result = await momo.checkStatus(req.params.id);
    res.json(result);
  } catch(e){ res.status(404).json({ error: e.message }); }
});

app.get('/api/balance', async (req,res)=>{
  const b = await momo.getBalance();
  res.json(b);
});

app.post('/api/receipt', async (req,res)=>{
  const pdf = await momo.generateReceipt(req.body);
  res.setHeader('Content-Type', 'application/pdf');
  res.send(pdf);
});

app.use('/webhook/momo', momo.webhookMiddleware(), (req,res)=>{
  console.log('✅ Webhook verified:', req.momoEvent);
  // Save to DB here
  res.json({ received: true, event: req.momoEvent });
});

app.get('/', (req,res)=>res.send(`
  <h1>MoMo Toolkit Demo 🇿🇲</h1>
  <p>POST /api/collect { phone: '+260976000000', amount: 100, reference: 'TEST-1' }</p>
  <p>POST /api/status/:id</p>
  <p>GET /api/balance</p>
  <p>POST /webhook/momo (webhook)</p>
`));

app.listen(3000, ()=>console.log('Demo running http://localhost:3000'));
