
function validatePhone(phone) {
  if (!phone) return false;
  // Zambia: +260 7x or 9x, 9 digits after 260
  const cleaned = phone.replace(/\s/g, '');
  const regex = /^\+260(7[5-9]|9[5-8])\d{7}$/;
  return regex.test(cleaned);
}

function detectProvider(phone) {
  const cleaned = phone.replace(/\s/g, '');
  // Zambia prefixes - simplified heuristic
  // MTN: 096, 097, 077 (historical), Airtel: 095, 097 overlap, 076, 077, 075
  // For demo: 096-097 MTN, 095/076/077 Airtel, fallback MTN
  const prefix = cleaned.slice(4, 6);
  const mtnPrefixes = ['96', '97']; // MTN Zambia main
  const airtelPrefixes = ['95', '76', '77', '75'];
  if (airtelPrefixes.includes(prefix)) return 'airtel';
  if (mtnPrefixes.includes(prefix)) return 'mtn';
  // default mtn (larger)
  return 'mtn';
}

function isValidAmount(amount) {
  const n = Number(amount);
  return !isNaN(n) && n > 0 && n <= 25000; // Zambia daily limit
}

module.exports = { validatePhone, detectProvider, isValidAmount };
