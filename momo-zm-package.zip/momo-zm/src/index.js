
const axios = require('axios');
const crypto = require('crypto');
const { v4: uuidv4 } = require('uuid');
const MTNClient = require('./providers/mtn');
const AirtelClient = require('./providers/airtel');
const { generateReceiptPDF } = require('./receipt');
const { validatePhone, detectProvider, isValidAmount } = require('./utils');

class MoMo {
  constructor(config = {}) {
    this.config = config;
    this.env = config.env || 'sandbox';
    this.defaultProvider = config.provider || 'auto';
    this.webhookSecret = config.webhookSecret || config.mtn?.webhookSecret || 'test_secret';
    
    this.mtn = new MTNClient(config.mtn || {}, this.env);
    this.airtel = new AirtelClient(config.airtel || {}, this.env);
    
    // In-memory store for sandbox mock
    this._transactions = new Map();
  }

  _resolveProvider(phone) {
    if (this.defaultProvider !== 'auto') return this.defaultProvider;
    return detectProvider(phone);
  }

  _getClient(provider) {
    if (provider === 'mtn') return this.mtn;
    if (provider === 'airtel') return this.airtel;
    throw new Error(`Unknown provider: ${provider}`);
  }

  async collect({ phone, amount, currency = 'ZMW', reference, description, payerMessage, payeeNote }) {
    if (!validatePhone(phone)) throw new Error(`Invalid Zambia phone: ${phone}. Expected +260XXXXXXXXX`);
    if (!isValidAmount(amount)) throw new Error(`Invalid amount: ${amount}`);
    if (currency !== 'ZMW') throw new Error(`Only ZMW supported for Zambia, got ${currency}`);
    if (!reference) reference = `REF-${Date.now()}`;

    const provider = this._resolveProvider(phone);
    const client = this._getClient(provider);
    
    // Sandbox mock
    if (this.env === 'sandbox' && !client.hasCredentials()) {
      const txId = uuidv4();
      const willFail = phone.endsWith('000001');
      this._transactions.set(txId, {
        transactionId: txId,
        provider,
        phone,
        amount,
        reference,
        status: 'PENDING',
        createdAt: new Date(),
        willFail
      });
      setTimeout(() => {
        const tx = this._transactions.get(txId);
        if (tx) tx.status = willFail ? 'FAILED' : 'SUCCESSFUL';
      }, 3000);
      return {
        transactionId: txId,
        provider,
        amount,
        currency,
        reference,
        status: 'PENDING',
        message: `Sandbox ${provider} collection initiated`
      };
    }

    return await client.collect({ phone, amount, currency, reference, description, payerMessage, payeeNote });
  }

  async disburse({ phone, amount, currency = 'ZMW', reference, description }) {
    if (!validatePhone(phone)) throw new Error(`Invalid Zambia phone: ${phone}`);
    if (!isValidAmount(amount)) throw new Error(`Invalid amount: ${amount}`);
    const provider = this._resolveProvider(phone);
    const client = this._getClient(provider);

    if (this.env === 'sandbox' && !client.hasCredentials()) {
      const txId = uuidv4();
      this._transactions.set(txId, { transactionId: txId, provider, phone, amount, reference, status: 'PENDING', createdAt: new Date(), willFail: false });
      setTimeout(() => { const tx = this._transactions.get(txId); if (tx) tx.status = 'SUCCESSFUL'; }, 2000);
      return { transactionId: txId, provider, status: 'PENDING' };
    }

    return await client.disburse({ phone, amount, currency, reference, description });
  }

  async checkStatus(transactionId) {
    if (this._transactions.has(transactionId)) {
      return this._transactions.get(transactionId);
    }
    // Try both providers
    try { return await this.mtn.checkStatus(transactionId); } catch {}
    try { return await this.airtel.checkStatus(transactionId); } catch {}
    throw new Error(`Transaction ${transactionId} not found`);
  }

  async refund(transactionId, amount) {
    const tx = await this.checkStatus(transactionId);
    const client = this._getClient(tx.provider);
    if (this.env === 'sandbox' && !client.hasCredentials()) {
      return { transactionId: uuidv4(), originalTransactionId: transactionId, status: 'SUCCESSFUL', amount: amount || tx.amount };
    }
    return await client.refund(transactionId, amount);
  }

  async getBalance() {
    const result = {};
    try { result.mtn = await this.mtn.getBalance(); } catch (e) { result.mtn = { error: e.message, mock: true, balance: 50000, currency: 'ZMW' }; }
    try { result.airtel = await this.airtel.getBalance(); } catch (e) { result.airtel = { error: e.message, mock: true, balance: 50000, currency: 'ZMW' }; }
    return result;
  }

  webhookMiddleware(options = {}) {
    const secret = options.secret || this.webhookSecret;
    return (req, res, next) => {
      try {
        let rawBody = '';
        if (req.rawBody) rawBody = req.rawBody;
        else if (typeof req.body === 'string') rawBody = req.body;
        else rawBody = JSON.stringify(req.body);

        const signature = req.headers['x-signature'] || req.headers['x-mtn-signature'] || req.headers['x-airtel-signature'];
        
        // In sandbox, skip verification if no signature, but log
        if (this.env !== 'sandbox' && signature) {
          const expected = crypto.createHmac('sha256', secret).update(rawBody).digest('hex');
          if (expected !== signature) {
            return res.status(401).json({ error: 'Invalid webhook signature' });
          }
        }

        const body = typeof req.body === 'object' ? req.body : JSON.parse(rawBody || '{}');
        
        // Normalize event
        const event = {
          provider: body.provider || (body.partyId ? detectProvider(body.partyId) : 'mtn'),
          event: body.event || body.status || 'collection.success',
          transactionId: body.transactionId || body.externalId || body.id,
          amount: body.amount || body.value,
          phone: body.phone || body.partyId || body.msisdn,
          status: body.status,
          reference: body.reference || body.externalId,
          raw: body,
          receivedAt: new Date().toISOString()
        };

        req.momoEvent = event;
        next();
      } catch (e) {
        console.error('Webhook parse error', e);
        res.status(400).json({ error: 'Invalid webhook payload' });
      }
    };
  }

  async generateReceipt(data) {
    return await generateReceiptPDF(data);
  }

  // Utility to create HMAC signature (for testing webhooks)
  createSignature(payload, secret = this.webhookSecret) {
    return crypto.createHmac('sha256', secret).update(typeof payload === 'string' ? payload : JSON.stringify(payload)).digest('hex');
  }
}

module.exports = MoMo;
module.exports.MoMo = MoMo;
