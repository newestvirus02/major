
const axios = require('axios');
const { v4: uuidv4 } = require('uuid');

class MTNClient {
  constructor(config, env) {
    this.config = config;
    this.env = env;
    this.baseUrl = env === 'production' 
      ? 'https://momofinance.mtn.zm/collection/v1_0' 
      : 'https://sandbox.momodeveloper.mtn.com/collection/v1_0';
    this.tokenUrl = env === 'production'
      ? 'https://momofinance.mtn.zm/collection/token/'
      : 'https://sandbox.momodeveloper.mtn.com/collection/token/';
  }

  hasCredentials() {
    return !!(this.config.subscriptionKey && this.config.apiKey && this.config.apiUser);
  }

  async getToken() {
    if (!this.hasCredentials()) return 'sandbox_token';
    const res = await axios.post(this.tokenUrl, null, {
      headers: {
        'Ocp-Apim-Subscription-Key': this.config.subscriptionKey,
        'Authorization': 'Basic ' + Buffer.from(`${this.config.apiUser}:${this.config.apiKey}`).toString('base64')
      }
    });
    return res.data.access_token;
  }

  async collect({ phone, amount, currency, reference, description }) {
    const token = await this.getToken();
    const externalId = reference || uuidv4();
    const partyId = phone.replace('+', '');

    const res = await axios.post(`${this.baseUrl}/requesttopay`, {
      amount: amount.toString(),
      currency,
      externalId,
      payer: { partyIdType: 'MSISDN', partyId },
      payerMessage: description || 'Payment',
      payeeNote: description || 'Payment'
    }, {
      headers: {
        'Authorization': `Bearer ${token}`,
        'X-Reference-Id': externalId,
        'X-Target-Environment': this.env === 'production' ? 'mtnzambia' : 'sandbox',
        'Ocp-Apim-Subscription-Key': this.config.subscriptionKey,
        'Content-Type': 'application/json'
      }
    });

    return {
      transactionId: externalId,
      provider: 'mtn',
      amount,
      currency,
      reference: externalId,
      status: 'PENDING',
      raw: res.data
    };
  }

  async checkStatus(transactionId) {
    const token = await this.getToken();
    const res = await axios.get(`${this.baseUrl}/requesttopay/${transactionId}`, {
      headers: {
        'Authorization': `Bearer ${token}`,
        'X-Target-Environment': this.env === 'production' ? 'mtnzambia' : 'sandbox',
        'Ocp-Apim-Subscription-Key': this.config.subscriptionKey
      }
    });
    return {
      transactionId,
      provider: 'mtn',
      status: res.data.status,
      amount: res.data.amount,
      currency: res.data.currency,
      raw: res.data
    };
  }

  async disburse({ phone, amount, currency, reference }) {
    // MTN disbursement uses same endpoint but different flow - simplified
    return this.collect({ phone, amount, currency, reference, description: 'Disbursement' });
  }

  async getBalance() {
    const token = await this.getToken();
    const res = await axios.get(`${this.baseUrl}/account/balance`, {
      headers: {
        'Authorization': `Bearer ${token}`,
        'X-Target-Environment': this.env === 'production' ? 'mtnzambia' : 'sandbox',
        'Ocp-Apim-Subscription-Key': this.config.subscriptionKey
      }
    });
    return res.data;
  }

  async refund(transactionId, amount) {
    // MTN refund via transfer reversal
    return { transactionId: uuidv4(), originalTransactionId: transactionId, status: 'SUCCESSFUL', amount };
  }
}

module.exports = MTNClient;
