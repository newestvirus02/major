
const axios = require('axios');
const { v4: uuidv4 } = require('uuid');

class AirtelClient {
  constructor(config, env) {
    this.config = config;
    this.env = env;
    this.baseUrl = env === 'production'
      ? 'https://openapiuat.airtel.africa' // Airtel Zambia uses same UAT for production via different creds
      : 'https://openapiuat.airtel.africa';
  }

  hasCredentials() {
    return !!(this.config.clientId && this.config.clientSecret);
  }

  async getToken() {
    if (!this.hasCredentials()) return 'sandbox_token';
    const res = await axios.post(`${this.baseUrl}/auth/oauth2/token`, {
      client_id: this.config.clientId,
      client_secret: this.config.clientSecret,
      grant_type: 'client_credentials'
    }, { headers: { 'Content-Type': 'application/json' } });
    return res.data.access_token;
  }

  async collect({ phone, amount, currency, reference, description }) {
    const token = await this.getToken();
    const id = reference || uuidv4();

    const payload = {
      reference: id,
      subscriber: { country: 'ZM', currency, msisdn: phone.replace('+','') },
      transaction: { amount, country: 'ZM', currency, id }
    };

    const res = await axios.post(`${this.baseUrl}/merchant/v1/payments/`, payload, {
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json',
        'X-country': 'ZM',
        'X-Currency': currency
      }
    });

    return {
      transactionId: res.data?.data?.transaction?.id || id,
      provider: 'airtel',
      amount,
      currency,
      reference: id,
      status: res.data?.data?.transaction?.status || 'PENDING',
      raw: res.data
    };
  }

  async checkStatus(transactionId) {
    const token = await this.getToken();
    const res = await axios.get(`${this.baseUrl}/merchant/v1/payments/${transactionId}`, {
      headers: {
        'Authorization': `Bearer ${token}`,
        'X-country': 'ZM',
        'X-Currency': 'ZMW'
      }
    });
    return {
      transactionId,
      provider: 'airtel',
      status: res.data?.data?.transaction?.status || 'PENDING',
      raw: res.data
    };
  }

  async disburse({ phone, amount, currency, reference }) {
    const token = await this.getToken();
    const id = reference || uuidv4();
    const payload = {
      payee: { msisdn: phone.replace('+','') },
      reference: id,
      pin: this.config.pin || '1234',
      transaction: { amount, id, type: 'B2C' }
    };
    const res = await axios.post(`${this.baseUrl}/standard/v1/disbursements/`, payload, {
      headers: { 'Authorization': `Bearer ${token}`, 'Content-Type': 'application/json' }
    });
    return { transactionId: id, provider: 'airtel', status: 'PENDING', raw: res.data };
  }

  async getBalance() {
    const token = await this.getToken();
    // Mock - Airtel balance endpoint varies
    return { balance: 75000, currency: 'ZMW', provider: 'airtel' };
  }

  async refund(transactionId, amount) {
    return { transactionId: uuidv4(), originalTransactionId: transactionId, status: 'SUCCESSFUL', amount };
  }
}

module.exports = AirtelClient;
