
// PDF receipt generation - uses pdfkit if available, fallback to JSON
async function generateReceiptPDF({ transactionId, provider, amount, fee = 0, phone, reference, senderName, receiverName, date = new Date() }) {
  try {
    const PDFDocument = require('pdfkit');
    const QRCode = require('qrcode');
    
    return new Promise(async (resolve, reject) => {
      const doc = new PDFDocument({ size: 'A5', margin: 40 });
      const buffers = [];
      doc.on('data', buffers.push.bind(buffers));
      doc.on('end', () => resolve(Buffer.concat(buffers)));
      
      // Header
      doc.fontSize(16).font('Helvetica-Bold').text(`${provider?.toUpperCase() || 'MOMO'} Money Zambia`, { align: 'center' });
      doc.fontSize(10).font('Helvetica').text('Mobile Money Transaction Receipt', { align: 'center' });
      doc.moveDown();
      
      // QR
      try {
        const qrDataUrl = await QRCode.toDataURL(transactionId || 'test');
        const qrBuffer = Buffer.from(qrDataUrl.split(',')[1], 'base64');
        doc.image(qrBuffer, doc.page.width/2 - 40, doc.y, { width: 80 });
        doc.moveDown(4);
      } catch {}
      
      doc.fontSize(9);
      const rows = [
        ['Transaction ID', transactionId || 'TXN-' + Date.now()],
        ['Provider', provider || 'mtn'],
        ['Reference', reference || '-'],
        ['Phone', phone || '+260...'],
        ['Sender', senderName || 'Customer'],
        ['Receiver', receiverName || 'Merchant'],
        ['Date', date instanceof Date ? date.toLocaleString('en-ZM') : date],
        ['Amount', `ZMW ${Number(amount).toFixed(2)}`],
        ['Fee', `ZMW ${Number(fee).toFixed(2)}`],
        ['Total', `ZMW ${(Number(amount)+Number(fee)).toFixed(2)}`],
        ['Status', 'SUCCESSFUL'],
        ['Currency', 'ZMW'],
      ];
      
      rows.forEach(([k,v]) => {
        doc.font('Helvetica-Bold').text(k + ': ', { continued: true });
        doc.font('Helvetica').text(v);
      });
      
      doc.moveDown();
      doc.fontSize(7).text('This receipt is ZRA compliant. BOZ Regulated. For queries contact MTN Zambia 100 or Airtel Zambia 111. Powered by @newestvirus02/momo-zm toolkit.', { align: 'center' });
      doc.end();
    });
  } catch (e) {
    // Fallback JSON if pdfkit not installed
    const receipt = {
      transactionId,
      provider,
      amount: `ZMW ${amount}`,
      fee: `ZMW ${fee}`,
      phone,
      reference,
      date,
      note: 'Install pdfkit and qrcode for PDF generation: npm install pdfkit qrcode'
    };
    return Buffer.from(JSON.stringify(receipt, null, 2));
  }
}

module.exports = { generateReceiptPDF };
