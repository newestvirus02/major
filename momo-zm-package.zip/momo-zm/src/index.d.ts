
export type Provider = 'mtn' | 'airtel' | 'auto';
export type Env = 'sandbox' | 'production';

export interface MoMoConfig {
  provider?: Provider;
  env?: Env;
  webhookSecret?: string;
  mtn?: {
    subscriptionKey?: string;
    apiKey?: string;
    apiUser?: string;
    callbackUrl?: string;
  };
  airtel?: {
    clientId?: string;
    clientSecret?: string;
    pin?: string;
    callbackUrl?: string;
  };
}

export interface CollectParams {
  phone: string;
  amount: number;
  currency?: 'ZMW';
  reference?: string;
  description?: string;
  payerMessage?: string;
  payeeNote?: string;
}

export class MoMo {
  constructor(config: MoMoConfig);
  collect(params: CollectParams): Promise<any>;
  disburse(params: CollectParams): Promise<any>;
  checkStatus(transactionId: string): Promise<any>;
  refund(transactionId: string, amount?: number): Promise<any>;
  getBalance(): Promise<any>;
  webhookMiddleware(options?: { secret?: string }): any;
  generateReceipt(data: any): Promise<Buffer>;
  createSignature(payload: any, secret?: string): string;
}

export default MoMo;
