
# MoMo Integration Toolkit 🇿🇲
### Reusable Node wrapper for MTN / Airtel Money Zambia

`npm install @newestvirus02/momo-zm`

Built for Zambia Fintech — Unified API for MTN MoMo and Airtel Money, webhooks with HMAC verification, ZRA-compliant receipt generation.

### Quick Start
```js
const MoMo = require('@newestvirus02/momo-zm');

const momo = new MoMo({
  provider: 'auto', // 'mtn' | 'airtel' | 'auto'
  env: 'sandbox', // 'sandbox' | 'production'
  mtn: {
    subscriptionKey: 'YOUR_MTN_SUB_KEY',
    apiKey: 'YOUR_MTN_API_KEY',
    apiUser: 'YOUR_MTN_API_USER',
    callbackUrl: 'https://yourdomain.com/webhook/momo'
  },
  airtel: {
    clientId: 'YOUR_AIRTEL_CLIENT_ID',
    clientSecret: 'YOUR_AIRTEL_SECRET',
    callbackUrl: 'https://yourdomain.com/webhook/momo'
  },
  webhookSecret: 'whsec_...' // for verifying incoming webhooks
});

// Collect (C2B)
const res = await momo.collect({
  phone: '+260976000000',
  amount: 100,
  currency: 'ZMW',
  reference: 'ORDER-123',
  description: 'Payment for shoes'
});
console.log(res.transactionId, res.status); // PENDING

// Check status
const status = await momo.checkStatus(res.transactionId);
console.log(status); // { status: 'SUCCESSFUL', ... }

// Webhook middleware (Express)
app.use('/webhook/momo', momo.webhookMiddleware(), (req,res)=>{
  console.log('MoMo event:', req.momoEvent);
  // req.momoEvent = { provider, event, transactionId, amount, phone, status, raw }
  res.sendStatus(200);
});

// Receipt PDF
const pdfBuffer = await momo.generateReceipt({
  transactionId: res.transactionId,
  provider: 'mtn',
  amount: 100,
  fee: 2.5,
  phone: '+260976000000',
  reference: 'ORDER-123'
});
// pdfBuffer is a Buffer - save or send
```

### API

#### `collect({ phone, amount, currency='ZMW', reference, description, payerMessage, payeeNote })`
C2B - collect money from customer. Auto-detects provider by prefix (097/096/095 = MTN, 097/076/077 = Airtel - Zambia).

#### `disburse({ phone, amount, reference, description })`
B2C - send money to customer (payouts).

#### `checkStatus(transactionId)`
Poll transaction status.

#### `refund(transactionId, amount?)`
Refund a transaction.

#### `getBalance()`
Get MoMo account balance for both providers.

#### `webhookMiddleware(options?)`
Express middleware that verifies HMAC signature (X-Signature header) and parses event.

#### `generateReceipt(data)`
Returns PDF buffer. ZRA compliant.

### Zambia Specifics
- Phone: Must be +260XXXXXXXXX. Validates 09x/07x Zambia format.
- Currency: ZMW only (enforced)
- Limits: MTN K20k/day, Airtel K25k/day (sandbox limits lower)
- Sandbox numbers: Use +260976000000 for success, +260976000001 for failure in sandbox

### Webhook Events
- `collection.success`
- `collection.failed`
- `disbursement.success`
- `disbursement.failed`
- `refund.success`

### BOZ / ZRA Compliance
Receipts include TPIN placeholder, QR code, fee breakdown, BOZ disclaimer.

License MIT - Made in Zambia 🇿🇲
